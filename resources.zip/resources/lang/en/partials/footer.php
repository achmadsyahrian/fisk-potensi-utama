<?php

return [
   'footer' => [
      'content' => 'Join us to begin your academic journey at one of the best higher education institutions in North Sumatra.'
   ]
];