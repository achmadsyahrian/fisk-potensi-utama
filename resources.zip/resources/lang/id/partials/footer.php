<?php

return [
   'footer' => [
      'content' => 'Bergabunglah dengan kami untuk memulai perjalanan akademis Anda di salah satu perguruan tinggi terbaik di Sumatera Utara.'
   ]
];