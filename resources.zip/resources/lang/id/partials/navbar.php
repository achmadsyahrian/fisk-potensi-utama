<?php

return [
   'navbar' => [
      'home' => 'Beranda',

      'about' => 'Tentang Fakultas',
      'purpose' => 'Visi & Misi',
      'research' => 'Penelitian',

      'academy' => 'Program Studi',
      'international' => 'Hubungan International',
      'english' => 'Pend. Bahasa Inggris',

      'information' => 'Informasi',
      'news' => 'Berita',
      'announcement' => 'Pengumuman',
      'announcement_all' => 'Semua',
      'announcement_thesis' => 'Skripsi',
      'announcement_internship' => 'PKL',
      'announcement_advisory' => 'Perwalian',
      'announcement_krs' => 'KRS',
      'announcement_exam' => 'Ujian',

      'contact' => 'Kontak Fakultas',
   ],
];